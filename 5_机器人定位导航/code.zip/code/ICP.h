#pragma once
#include <iostream>
#include <opencv2/core/core.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <chrono>
#include <opencv2/video/tracking.hpp>
#include <Eigen/Dense>

using namespace std;
using namespace cv;

class ICP
{
public:
	Mat original_depth_image;
	Mat new_depth_image;

	float horizontalFOV;	//���ˮƽ�ӳ���
	float verticalFOV;		//�����ֱ�ӳ���
	int height;		//ͼ���������ߣ�
	int width;		//ͼ������������

	vector<float> original_depths;
	vector<float> new_depths;
	vector<Point3f> original_points;
	vector<Point3f> new_points;
	Mat R;
	Mat t;
	void pose_estimation_3d3d(const vector<Point3f>& pts1, const vector<Point3f>& pts2);
	void depthToPointCloud(vector<Point2f> old_Points, vector<Point2f> new_Points, vector<Point3f>& old_result_Points, vector<Point3f>& new_result_Points);
	void ICP_init(Mat first_Image, double fx, double fy);
	void ICP_run(Mat now_image, vector<Point2f> old_Points, vector<Point2f> new_Points);
};

