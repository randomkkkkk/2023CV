#include "ICP.h"


void ICP::depthToPointCloud(vector<Point2f> old_Points, vector<Point2f> new_Points, vector<Point3f>& old_result_Points, vector<Point3f>& new_result_Points) {

	old_result_Points.clear();
	new_result_Points.clear();
	int size = old_Points.size();
	cv::Point3f old_point;
	cv::Point3f new_point;
	
	for (int i = 0; i < size; ++i) {
		// ���ӳ���ת��Ϊ����
		double half_fov_x = horizontalFOV * CV_PI / 360.0;
		double half_fov_y = verticalFOV * CV_PI / 360.0;
		// �����һ������
		double old_norm_u = old_Points[i].x / width;
		double old_norm_v = old_Points[i].y / height;
		double old_depth = original_depth_image.data[(int)(old_Points[i].y * width + old_Points[i].x)];
		old_point.z = old_depth;
		old_point.x = old_depth * tan(old_norm_u * 2 * half_fov_x - half_fov_x);
		old_point.y = old_depth * tan(old_norm_v * 2 * half_fov_y - half_fov_y);

		double new_norm_u = new_Points[i].x / width;
		double new_norm_v = new_Points[i].y / height;
		double new_depth = new_depth_image.data[int(new_Points[i].y * width + new_Points[i].x)] / 5000;
		new_point.z = new_depth;
		new_point.x = new_depth * tan(new_norm_u * 2 * half_fov_x - half_fov_x);
		new_point.y = new_depth * tan(new_norm_v * 2 * half_fov_y - half_fov_y);

		old_result_Points.push_back(old_point);
		new_result_Points.push_back(new_point);
	}
}

void ICP::ICP_init(Mat first_Image, double fx, double fy)
{
	// ��ȡͼ��Ŀ��͸�
	width = first_Image.cols;
	height = first_Image.rows;

	// ����FOV
	double focalLength = (fx + fy) / 2.0;
	horizontalFOV = 2.0 * std::atan(width / (2.0 * focalLength)) * 180.0 / CV_PI;
	verticalFOV = 2.0 * std::atan(height / (2.0 * focalLength)) * 180.0 / CV_PI;
	first_Image.copyTo(new_depth_image);
}

void ICP::ICP_run(Mat now_image, vector<Point2f> old_Points, vector<Point2f> new_Points)
{
	new_depth_image.copyTo(original_depth_image);
	now_image.copyTo(new_depth_image);
	depthToPointCloud(old_Points, new_Points, original_points, new_points);
	pose_estimation_3d3d(original_points, new_points);
}

void ICP::pose_estimation_3d3d(const vector<Point3f>&pts1, const vector<Point3f>& pts2) {
	Point3f p1, p2;     // center of mass
	int N = pts1.size();
	for (int i = 0; i < N; i++) {
		p1 += pts1[i];
		p2 += pts2[i];
	}
	p1 = Point3f(Vec3f(p1) / N);
	p2 = Point3f(Vec3f(p2) / N);
	vector<Point3f> q1(N), q2(N); // remove the center
	for (int i = 0; i < N; i++) {
		q1[i] = pts1[i] - p1;
		q2[i] = pts2[i] - p2;
	}

	// compute q1*q2^T
	Eigen::Matrix3d W = Eigen::Matrix3d::Zero();
	for (int i = 0; i < N; i++) {
		W += Eigen::Vector3d(q1[i].x, q1[i].y, q1[i].z) * Eigen::Vector3d(q2[i].x, q2[i].y, q2[i].z).transpose();
	}
	//cout << "W=" << W << endl;

	// SVD on W
	Eigen::JacobiSVD<Eigen::Matrix3d> svd(W, Eigen::ComputeFullU | Eigen::ComputeFullV);
	Eigen::Matrix3d U = svd.matrixU();
	Eigen::Matrix3d V = svd.matrixV();

	//cout << "U=" << U << endl;
	//cout << "V=" << V << endl;

	Eigen::Matrix3d R_ = U * (V.transpose());
	if (R_.determinant() < 0) {
		R_ = -R_;
	}
	Eigen::Vector3d t_ = Eigen::Vector3d(p1.x, p1.y, p1.z) - R_ * Eigen::Vector3d(p2.x, p2.y, p2.z);

	Mat R0;
	Mat t0;
	R0 = (Mat_<double>(3, 3) <<
		R_(0, 0), R_(0, 1), R_(0, 2),
		R_(1, 0), R_(1, 1), R_(1, 2),
		R_(2, 0), R_(2, 1), R_(2, 2)
		);
	t0 = (Mat_<double>(3, 1) << t_(0, 0), t_(1, 0), t_(2, 0));
	R0.copyTo(R);
	t0.copyTo(t);
}