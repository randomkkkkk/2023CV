#include <fstream>
#include "visual_odometry.h"
#include "ICP.h"

int findPosition(const std::vector<float>& nums, float target, float& diffRatio) {
    int left = 0;
    int right = nums.size() - 1;

    while (left < right) {
        int mid = left + (right - left) / 2;

        if (nums[mid] == target) {
            diffRatio = 0.0f;  // Ŀ����ֵ���м�����ȣ���ֵ����Ϊ0
            return mid;  // �ҵ���Ŀ����ֵ�����ض�Ӧλ��
        }
        else if (nums[mid] < target) {
            left = mid + 1;  // Ŀ����ֵ���Ҳ࣬������߽�
        }
        else {
            right = mid;  // Ŀ����ֵ����࣬�����ұ߽�
        }
    }

    // Ŀ����ֵ���������У�����Ŀ����ֵӦ�ò����λ��
    diffRatio = (target - nums[right]) / ((nums[left] - nums[right]) + (target - nums[right]));
    return left;
}

void get_picture_data(std::vector<float>& timestamps, std::vector<std::string>& imageNames, std::string filePath) {
    std::ifstream file(filePath);
    std::string line;
    while (std::getline(file, line)) {
        std::istringstream iss(line);
        float timestamp;
        std::string imageName;

        if (iss >> timestamp >> imageName) {
            timestamps.push_back(timestamp);
            imageNames.push_back(imageName);
        }
    }

    file.close();
}

void saveVectorMatToCSV(const std::vector<cv::Mat>& vecMat, const std::string& filename) {
    std::ofstream file(filename);

    if (!file.is_open()) {
        std::cout << "Failed to open file: " << filename << std::endl;
        return;
    }

    for (const cv::Mat_<double>& mat : vecMat) {
        for (int i = 0; i < mat.rows; ++i) {
            for (int j = 0; j < mat.cols; ++j) {
                file << mat(i, j);

                if (j < mat.cols - 1) {
                    file << ",";
                }
            }

            if (i < mat.rows - 1) {
                file << ",";
            }
        }

        file << "\n";
    }

    file.close();
    std::cout << "Vector of Mat data saved to file: " << filename << std::endl;
}

int main() {
    string rgb_file = ("C:\\Users\\ASUS\\Desktop\\rgbd_dataset_freiburg1_xyz\\rgb.txt");
    string depth_file = ("C:\\Users\\ASUS\\Desktop\\rgbd_dataset_freiburg1_xyz\\depth.txt");
    vector<float> rgb_timestamps;
    vector<string> rgb_imageNames;
    vector<float> depth_timestamps;
    vector<string> depth_imageNames;
    vector<Mat> results;
    get_picture_data(rgb_timestamps, rgb_imageNames, rgb_file);
    get_picture_data(depth_timestamps, depth_imageNames, depth_file);
    float Ratio;
    visual_odometry visualOdometry;
    ICP icp;
    Mat image, image_depth;

    // ����ͼ���ļ���·��
    string folderPath = "C:\\Users\\ASUS\\Desktop\\rgbd_dataset_freiburg1_xyz\\rgb\\";
    string depth_folderPath = "C:\\Users\\ASUS\\Desktop\\rgbd_dataset_freiburg1_xyz\\depth\\";
    // ��������Ƿ�Ϊ��
    if (rgb_imageNames.empty()) {
        cout << "ͼ���ļ�������Ϊ��" << endl;
        return -1;
    }

    // ��һ��ͼ����ļ���
    string firstImageName = rgb_imageNames[0].substr(4);
    string depthImageName = depth_imageNames[0].substr(6);
    // ����init����������һ��ͼ��
    Mat firstImage = imread(folderPath + firstImageName);
    Mat firstDepthImage = imread(depth_folderPath + depthImageName);
    visualOdometry.odom_init(firstImage, 517.3, 516.5);
    icp.ICP_init(firstDepthImage, 517.3, 516.5);
    // ����ʣ���ͼ���ļ���������run��������ÿ��ͼ��
    for(size_t i = 1; i < rgb_imageNames.size(); ++i) {
        cout << i << endl;
        if (i > 10)
            break;
        string currentImageName = rgb_imageNames[i].substr(4);
        // �����������ļ�·��
        string imagePath = folderPath + currentImageName;
        
        //if (rgb_timestamps[i] >= depth_timestamps.back() || depth_timestamps.front() >= rgb_timestamps[i])
        //{
        //    cout << depth_timestamps.front() << endl;
        //    cout << rgb_timestamps[i] << endl;
        //    cout << depth_timestamps.back() << endl;
        //    continue;
        //}
        //    
        //findPosition(depth_timestamps, rgb_timestamps[i], Ratio);
        // ��ȡͼ��
        image = imread(imagePath);
        visualOdometry.LK_run(image);
        string currentDepthImageName = depth_imageNames[i].substr(6);
        string depthImagePath = folderPath + currentImageName;
        image_depth = imread(depthImagePath);
        icp.ICP_run(image_depth, visualOdometry.pt_original, visualOdometry.pt_new);
        results.push_back(icp.t);
    }
    // ����t�� CSV �ļ�
    saveVectorMatToCSV(results, "output.csv");
    return 0;
}
